from fractions import Fraction as Q
from itertools import combinations,product
from collections import Counter
from random import Random
from math import inf
from sympy import symbols,simplify
A=tuple(sorted({Q(0)}|{Q(2*j+1,40) for j in range(41)}))
def table(d,F):
 n=len(d);z=[Q(0)]
 for a in d[:-1]:z.append(z[-1]+a)
 D={}
 for k in range(n+1):
  for S in combinations(range(n),k):
   if not S:D[S]=((),Q(2));continue
   g=[z[b]-z[a] for a,b in zip(S,S[1:])]+[1+z[S[0]]-z[S[-1]]]
   D[S]=(tuple((g[j-1]+g[j])/2 for j in range(k)),k*F+sum(x*x/4 for x in g))
 I={}
 for S,(q,c) in D.items():
  v=[]
  for i in range(n):
   if i not in S:
    R=tuple(sorted(S+(i,)));v.append(2*D[R][0][R.index(i)])
  I[S]=(max(v,default=-inf),min((2*x for x in q),default=inf))
 return D,I
def ne(I,x):return [s for s,(l,h) in I.items() if l<=x<=h]
def limits(d):
 h=[d[i-1]+d[i] for i in range(len(d))];return min(h),min(max(h[::2]),max(h[1::2])),min(d[i-1]+d[i]+d[(i+1)%len(d)] for i in range(len(d)))
def mixopt(rows):
 best=min((max(r,s),x,x,Q(1)) for x,r,s in rows)
 for x,r,s in rows:
  for y,u,v in rows:
   a=r-s-u+v
   if a:
    p=(v-u)/a
    if 0<=p<=1:best=min(best,(max(p*r+(1-p)*u,p*s+(1-p)*v),x,y,p))
 return best
def audit(d,e,F,menu=A,detail=False,mix=False):
 n=len(d);full=tuple(range(n));D,I=table(d,F);B,J=table(e,F);assert D[full][0]==B[full][0]
 H,T,K=limits(d);H2,T2,K2=limits(e);assert (H,T)==(H2,T2)
 c=Counter();cost=[];failure=[]
 for x in menu:
  E=ne(I,x);G=ne(J,x);assert E and G
  common={(s,D[s][0]) for s in E}&{(s,B[s][0]) for s in G}
  if x<=H or x>=T:assert common
  if H<x<T and max(K,K2)>=T:assert not common
  if not common:failure.append(x)
  cost.append((x,max(D[s][1] for s in E),max(B[s][1] for s in G)));c['policies']+=1;c['pure_NE']+=len(E)+len(G)
 a=min(x[1] for x in cost);b=min(x[2] for x in cost);rows=[(x,r-a,s-b) for x,r,s in cost];det=min(max(r,s) for _,r,s in rows);m=mixopt(rows) if mix else None
 if detail:print('DETAIL',n,'d',d,'e',e,'F',F,'H,T,K,K2',H,T,K,K2,'reveal',failure,'B0',min(c for q,c in D.values()),min(c for q,c in B.values()),'B1',a,b,'optU',[x for x,r,s in rows if r==0],'optC',[x for x,r,s in rows if s==0],'B2det',det,'B2mix',m,flush=True)
 return c,not failure,det
if __name__=='__main__':
 a,b,t=symbols('a b t');assert simplify(t*((a+b)**2-a*a-b*b)/4-t*a*b/2)==0
 print('predeclared menu',len(A),A[0],A[-1],flush=True)
 rng=Random(20261117);counts=Counter()
 for n in (4,6,8,10):
  a=Q(1,20) if n==4 else Q(1,100*n*n);F=Q(1,50) if n==4 else Q(1,8*n*(n-1));b=Q(2,n)-a
  U=(Q(1,n),)*n;C=(a,b)*(n//2);H0=Q(2,n)
  for j in range(5):
   w=[rng.randint(-5,5) for i in range(n)];m=sum(w);u=tuple(Q(n*v-m,n*10)*a/20 for v in w)
   d=tuple(x+y for x,y in zip(U,u));e=tuple(x+y for x,y in zip(C,u))
   if limits(d)[0]==H0:continue
   out,blind,det=audit(d,e,F,detail=j==0,mix=j==0);counts.update(out);counts['pairs']+=1;counts['blind']+=blind;counts['blind_positive_regret']+=blind and det>0
   out2,blind2,_=audit(d,e,F,tuple(sorted(set(A)|{H0})));counts['alignment_identifies']+=not blind2;counts['alignment_tests']+=1;counts['aligned_policies']+=out2['policies']
 print('EXPLORATORY',dict(counts),flush=True)
 d=tuple(map(Q,('0.252','0.251','0.249','0.248')));e=tuple(x+(-1)**i*Q(-1,5) for i,x in enumerate(d));F=Q(1,50)
 audit(d,e,F,detail=True,mix=True);audit(d,e,F,tuple(sorted(set(A)|{Q(1,2)})),detail=True,mix=True)
 d0=(Q(1,4),)*4;e0=(Q(1,20),Q(9,20))*2;eta=Q(1,200)
 assert Q(1,40)>2*eta and Q(1,40)<Q(1,20)-3*eta
 assert (Q(1,4)-eta)**2/2>F>(Q(1,20)+eta)*(Q(9,20)+eta)/2
 c=Counter()
 for w in product(range(-2,3),repeat=3):
  u=tuple(Q(x,1000) for x in w)+(Q(-sum(w),1000),)
  if max(map(abs,u))>=eta:continue
  d=tuple(a+b for a,b in zip(d0,u));e=tuple(a+b for a,b in zip(e0,u))
  if limits(d)[0]==Q(1,2):continue
  sub,blind,det=audit(d,e,F);assert blind and det>0;c.update(sub);c['pairs']+=1
 print('OPEN REGION GRID',dict(c),flush=True)
