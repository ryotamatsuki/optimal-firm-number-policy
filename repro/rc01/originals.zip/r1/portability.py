from fractions import Fraction as Q
from itertools import combinations
from functools import lru_cache
from sympy import symbols, simplify
from pathlib import Path
import sys

A=tuple([Q(0)]+[Q(2*j+1,40) for j in range(41)])
U=tuple(map(Q,('.252','.249','.250','.249')))
C=tuple(map(Q,('.052','.449','.050','.449')))
U0=(Q(1,4),)*4; C0=(Q(1,20),Q(9,20))*2
F=Q(1,50); V=Q(2)

def integral(poly,l,r): return sum(c*(r**(i+1)-l**(i+1))/(i+1) for i,c in enumerate(poly))
def mul(a,b):
 c=[Q(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b): c[i+j]+=x*y
 return c

def worlds(d,density,power):
 n=len(d); z=[Q(0)]
 for v in d[:-1]: z.append(z[-1]+v)
 profiles={}
 for k in range(n+1):
  for S in combinations(range(n),k):
   q=[Q(0)]*n; T=Q(0)
   if S:
    images=sorted((z[i]+shift,i) for i in S for shift in (-1,0,1))
    for j,(y,i) in enumerate(images):
     l=max(Q(0),(images[j-1][0]+y)/2) if j else Q(0)
     r=min(Q(1),(images[j+1][0]+y)/2) if j+1<len(images) else Q(1)
     if r<=l:continue
     q[i]+=integral(density,l,r)
     if power==2:T+=integral(mul(density,[y*y,-2*y,Q(1)]),l,r)
     else:
      m=max(l,min(y,r))
      T+=integral(mul(density,[y,-Q(1)]),l,m)+integral(mul(density,[-y,Q(1)]),m,r)
    assert sum(q)==1
   profiles[S]=(tuple(q),T)
 return profiles

def eq(profiles,theta):
 n=len(next(iter(profiles.values()))[0]); out=[]
 for S,(q,T) in profiles.items():
  if all(2*q[i]>=theta if i in S else 2*profiles[tuple(sorted(S+(i,)))][0][i]<=theta for i in range(n)):out.append(S)
 return out

def compare(p1,p2,F,menu=A):
 W=[];overlap=[]; counts=0
 for theta in menu:
  E=[eq(P,theta) for P in (p1,p2)]; assert all(E)
  counts+=sum(map(len,E)); S=[{(s,P[s][0]) for s in e} for P,e in zip((p1,p2),E)]
  overlap.append(bool(S[0]&S[1])); W.append([max(F*len(s)+P[s][1] if s else V for s in e) for P,e in zip((p1,p2),E)])
 opt=[min(w[i] for w in W) for i in (0,1)]
 optimum=[tuple(x for x,w in zip(menu,W) if w[i]==opt[i]) for i in (0,1)]
 regret=min(max(w[i]-opt[i] for i in (0,1)) for w in W)
 print('full shares',p1[(0,1,2,3)][0],p2[(0,1,2,3)][0]); print('overlap',sum(overlap),'/',len(menu),'NE occurrences',counts,'optimum robust costs',opt,'optimal menus',optimum,'static regret',regret)
 return overlap,optimum,regret

base=[worlds(d,[Q(1)],1) for d in (U,C)]
print('BASELINE'); o,b,r=compare(*base,F);assert all(o) and not(set(b[0])&set(b[1])) and r>0
print('BASELINE ADD MIDPOINT');o,b,r=compare(*base,F,tuple(sorted(A+(Q(1,2),))));assert not all(o)
print('QUADRATIC same F');quad=[worlds(d,[Q(1)],2) for d in (U,C)];assert all(P[s][0]==B[s][0] for P,B in zip(quad,base) for s in P)
o,b,r=compare(*quad,F);assert all(o);print('same policy optimum?',bool(set(b[0])&set(b[1])))
print('QUADRATIC symmetric control F=.005');quad0=[worlds(d,[Q(1)],2) for d in (U0,C0)];o,b,r=compare(*quad0,Q(1,200));assert all(o)
print('NONUNIFORM density');den=[worlds(d,[Q(1,2),Q(1)],1) for d in (U,C)];o,b,r=compare(*den,F);assert not o[0]
# Analytic identity and previous numerical lower bound independent recomputation.
a,b,t=symbols('a b t');assert simplify(t*((a+b)**3-a**3-b**3)/12-t*a*b*(a+b)/4)==0
eta=Q(1,200);a=Q(1,20);b=Q(9,20);gamma=(Q(1,4)-eta)**2/2-F;delta=F-(a+eta)*(b+eta)/2
print('P5 uniform bounds',gamma,delta,gamma*delta/(gamma+delta),float(gamma*delta/(gamma+delta)))
print('PASS',sys.version.split()[0])
