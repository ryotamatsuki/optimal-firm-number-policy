R-C01 R1 | Finite policy resolution | 2026-11-17 JST

Reproduction (Python 3.13.5, SymPy 1.14.0):
  python stage04.py > stage04_reproduced.txt
  python stage04a.py > stage04a_reproduced.txt

The two programs were actually run and their original stdout is included.
The second evaluator independently integrates periodic-image Voronoi cells and enumerates binary deviations. The AI author of the evaluator had access to the production claims, so this is not blind or independent human review.
Values labeled regret in identifying-menu controls are static no-learning diagnostics, not regret after successful adaptive identification. The latter can be zero.

Full research report and prospective plan:
https://github.com/ryotamatsuki/optimal-firm-number-policy/tree/main/research/rc01/resolution_r1

Formal verification and author substantive sign-off remain pending. Exact pure-strategy circular-market scope only.
