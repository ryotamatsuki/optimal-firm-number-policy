# independent evaluator: direct nearest periodic-image cells, bit masks; no production solver import
from fractions import Fraction as Q
from itertools import combinations,product
from collections import Counter
from random import Random
A=tuple(sorted({Q(0)}|{Q(2*j+1,40) for j in range(41)}))
def pos(d):
 z=[Q(0)]
 for x in d[:-1]:z.append(z[-1]+x)
 return z
def game(d,F):
 z=pos(d);n=len(z);P={};cost={}
 for s in range(1<<n):
  if not s:P[s]=(Q(0),)*n;cost[s]=Q(2);continue
  im=sorted((z[i]+k,i) for i in range(n) if s>>i&1 for k in (-1,0,1));q=[Q(0)]*n;T=Q(0)
  for j,(y,i) in enumerate(im):
   l=max(Q(0),(im[j-1][0]+y)/2) if j else Q(0);r=min(Q(1),(im[j+1][0]+y)/2) if j+1<len(im) else Q(1)
   if r<=l:continue
   q[i]+=r-l;T+=((r-y)*abs(r-y)-(l-y)*abs(l-y))/2
  assert sum(q)==1;P[s]=tuple(q);cost[s]=F*s.bit_count()+T
 D={s:tuple((bool(s>>i&1),2*P[s|1<<i][i]) for i in range(n)) for s in P}
 return P,cost,D
def ne(D,x):return [s for s,row in D.items() if all(x<=u if on else x>=u for on,u in row)]
def stats(d,e,F,menu,cnt,details=False):
 n=len(d);full=(1<<n)-1;P,C,D=game(d,F);R,V,J=game(e,F);assert P[full]==R[full]
 h=[2*x for x in P[full]];H=min(h);T=min(max(h[::2]),max(h[1::2]));K=min(sum(d[(i+j)%n] for j in range(3)) for i in range(n));K2=min(sum(e[(i+j)%n] for j in range(3)) for i in range(n))
 # Include BOTH threshold boundaries and every midpoint of actual deviation thresholds.
 points=sorted({x for M in (D,J) for row in M.values() for on,x in row}|set(menu)|{H,T});G=sorted(set(points+[(x+y)/2 for x,y in zip(points,points[1:])]+[-Q(1),Q(3)]))
 overlaps={};vals={}
 for x in G:
  E=ne(D,x);B=ne(J,x);assert E and B;common={(s,P[s]) for s in E}&{(s,R[s]) for s in B};overlaps[x]=bool(common);vals[x]=(max(C[s] for s in E),max(V[s] for s in B));cnt['regimes']+=1;cnt['pure_NE']+=len(E)+len(B);cnt['conditions']+=n*(len(D)+len(J))
  if x<=H or x>=T:assert common
  if H<x<T and max(K,K2)>=T:assert not common
  if H<x<T and K>=T:assert all(P[s]!=R[s] for s in E)
  if H<x<T and K2>=T:assert all(P[s]!=R[s] for s in B)
  if H<x<T and common:cnt['interior_overlap_outside_triple_domain']+=1
  if H<x<T and not common:cnt['interior_separations']+=1
  for M,L in ((D,E),(J,B)):
   for s in L:
    for i,(_,v) in enumerate(M[s]):
     if v==x:
      cnt['indifference_flips']+=1;s2=s^(1<<i);cnt['flip_retained']+=all(x<=v2 if on else x>=v2 for on,v2 in M[s2])
 a=min(vals[x][0] for x in menu);b=min(vals[x][1] for x in menu);rows=[(x,vals[x][0]-a,vals[x][1]-b) for x in menu];det=min(max(r,s) for x,r,s in rows);mx=det
 for _,r,s in rows:
  for _,u,v in rows:
   z=r-s-u+v
   if z:
    p=(v-u)/z
    if 0<=p<=1:mx=min(mx,max(p*r+(1-p)*u,p*s+(1-p)*v))
 blind=all(overlaps[x] for x in menu)
 if details:print('EXAMPLE',d,e,'H,T,K,K2',H,T,K,K2,'menu_blind',blind,'revealing',[x for x in menu if not overlaps[x]],'planner',min(C.values()),min(V.values()),'robust',a,b,'regret',det,mx,'cost0',vals[Q(0)],'cost .525',vals.get(Q(21,40)),flush=True)
 return H,T,K,K2,blind,det,mx,overlaps,vals
if __name__=='__main__':
 rng=Random(90291);cnt=Counter();F=Q(1,50)
 for n in (4,6,8):
  for j in range(9):
   if j<3:
    a=Q(j+1,10*n);base=(a,Q(2,n)-a)*(n//2)
   else:
    w=[rng.randint(1,45) for _ in range(n)];base=tuple(Q(v,sum(w)) for v in w)
   delta=min(base[::2])/3;e=tuple(v-(-1)**i*delta for i,v in enumerate(base));assert min(e)>0
   stats(base,e,F,A,cnt);cnt['general_pairs']+=1
 # strict neighborhood, including both parity maxima and aligned action H0
 for w in product((-3,0,3),repeat=3):
  u=tuple(Q(v,1000) for v in w)+(Q(-sum(w),1000),)
  if max(map(abs,u))>=Q(1,200):continue
  d=tuple(Q(1,4)+v for v in u);e=tuple((Q(1,20) if i%2==0 else Q(9,20))+v for i,v in enumerate(u));h=[d[i-1]+d[i] for i in range(4)]
  if min(h)==Q(1,2):continue
  H,T,K,K2,blind,det,mx,ov,vals=stats(d,e,F,A,cnt);assert blind and det>0 and mx>0;cnt['open_region_pairs']+=1
  gam=(Q(1,4)-Q(1,200))**2/2-F;Dlt=F-(Q(1,20)+Q(1,200))*(Q(9,20)+Q(1,200))/2
  assert det>=min(gam,Dlt) and mx>=gam*Dlt/(gam+Dlt)
  if H<Q(1,2)<T:assert not ov[Q(1,2)];cnt['aligned_reveals']+=1
  elif T==Q(1,2):assert ov[Q(1,2)];cnt['aligned_at_T_blind']+=1
 # Two clear examples showing alignment is not sufficient and witness open band.
 for w in [('0.252','0.249','0.250','0.249'),('0.252','0.251','0.249','0.248')]:
  d=tuple(map(Q,w));e=tuple(v-(-1)**i*Q(1,5) for i,v in enumerate(d));stats(d,e,F,A,cnt,True);stats(d,e,F,tuple(sorted(set(A)|{Q(1,2)})),cnt,True)
 # necessity of triple constraint: two close geometries with same nonuniform h;
 # common adjacent pair can be a pure NE below T where a long active gap covers two idle labels.
 d=tuple(map(Q,('.7','.1','.1','.1')));e=tuple(v+(-1)**i*Q(1,50) for i,v in enumerate(d));H,T,K,K2,blind,det,mx,ov,_=stats(d,e,F,tuple(sorted(set(A)|{Q(2,5)})),cnt,True);assert H<Q(2,5)<T and ov[Q(2,5)]
 # Coarse menu can eliminate any profitable exit policy; relative benchmark same.
 d=tuple(map(Q,('.252','.249','.250','.249')));e=tuple(v-(-1)**i*Q(1,5) for i,v in enumerate(d));*_,blind,det,mx,ov,vals=stats(d,e,F,(Q(0),Q(3)),cnt,True);assert blind and det==0 and mx==0
 print('COUNTS',dict(cnt));print('PASS')
